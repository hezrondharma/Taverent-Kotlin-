
<?php $__env->startSection('title','Penginap'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/penginap.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("extrajs"); ?>
    <script src="/java/penginap.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpenginap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="height:auto;padding-bottom:100px;padding-top:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;">

<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/>
</svg>
<form action="" method="post" style="height:auto;width:50%;display:flex;flex-direction:column;"><?php echo csrf_field(); ?>
    Username    <br>
    <input type="text" class="form-control" name="username" value="<?php echo e(old('username',Session::get('penyewa')->username)); ?>">
    <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="label text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    Email    <br>
    <input type="text" class="form-control"  name="email" value="<?php echo e(old('email',Session::get('penyewa')->email)); ?>">
    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="label text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    Nomor Telepon    <br>
    <input type="text" class="form-control"  name="no_telp" value="<?php echo e(old('no_telp',Session::get('penyewa')->no_telp)); ?>">
    <?php $__errorArgs = ["no_telp"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="label text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    Password    <br>
    <input type="password" class="form-control"  name="password" value="<?php echo e(old('password',Session::get('penyewa')->password)); ?>">
    <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="label text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    <?php if(Session::has("success")): ?>
    <label class="label text-success"><?php echo e(Session::get("success")); ?></label>
    <?php endif; ?>
    <input type="submit" value="Update Profile" class="btn btn-success">
    
</form>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/penyewa/profil.blade.php ENDPATH**/ ?>