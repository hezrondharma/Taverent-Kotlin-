
<?php $__env->startSection('title','List Pengumuman'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>

    <nav class="main-menu">
        <ul>
            <li class="has-subnav">
                <a href="/admin/listpenginap">
                    <i class="fa fa-list fa-2x"></i>
                    <span class="nav-text">
                        List Penginap
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpemilik">
                    <i class="fa fa-key fa-2x"></i>
                    <span class="nav-text">
                        List Pemilik
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpenginapan">
                    <i class="fa fa-inbox fa-2x"></i>
                    <span class="nav-text">
                        List Penginapan
                    </span>
                </a>

            </li>

            <li>
                <a href="/admin/listnotifikasi">
                    <i class="fa fa-bell fa-2x"></i>
                    <span class="nav-text">
                        List Notifikasi
                    </span>
                </a>
            </li>
            <li>
                <a href="/admin/mail">
                    <i class="fa fa-envelope fa-2x"></i>
                    <span class="nav-text">
                        Send Mail
                    </span>
                </a>
            </li>

            
        </ul>

        <ul class="logout">
            <li>
                <a href="/admin/logout">
                        <i class="fa fa-power-off fa-2x"></i>
                    <span class="nav-text">
                        Logout
                    </span>
                </a>
            </li>
        </ul>
    </nav>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="area">
    <br>
    <?php if(Session::has("pesanSukses")): ?>
        <div class="alert alert-success"><?php echo e(Session::get("pesanSukses")); ?></div>
    <?php endif; ?>

    <?php if(Session::has("pesanGagal")): ?>
        <div class="alert alert-danger"><?php echo e(Session::get("pesanGagal")); ?></div>
    <?php endif; ?>
    <h1>Tambah Pengumuman</h1>
    <form action="<?php echo e(url("admin/listnotifikasi")); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Judul</label>
            <input type="text" name="title" id="" class="form-control" placeholder="Judul Pengumuman" value="<?php echo e(old('title')); ?>">
            <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="title"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Isi</label>
            <textarea name="isi" rows="4" cols="50" class="form-control"><?php echo e(old('isi')); ?></textarea>
            <?php $__errorArgs = ["isi"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="isi"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-4">
            <label class="form-label">Jenis</label><br>
            <label class="label" for="name">Penginap</label>  <input type="radio" name="rbJenis" value="penginap"><i class="validation"></i>
            <label class="label" for="name">Pemilik</label> <input type="radio" name="rbJenis" value="pemilik"><i class="validation"></i>
            <?php $__errorArgs = ["rbJenis"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="rbJenis"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <input type="submit" value="tambah" class="btn btn-success">
        </div>
    </form>
<br>
<h1>List Pengumuman</h1>
    <?php if(!$notifikasi->isEmpty()): ?>
        <table class="table table-striped table-hover table-bordered border-dark">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Isi</th>
                    <th>Kepada</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($notif->id); ?></td>
                        <td><?php echo e($notif->judul); ?></td>
                        <td><?php echo e($notif->isi); ?></td>
                        <td> <?php echo ($notif->tipe == 0)? "Penginap" : "Pemilik" ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url("admin/listnotifikasi/hapus/$notif->id")); ?>" class="btn btn-danger">Hapus</a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
    <h1>tidak ada daftar notifikasi</h1>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/Admin/listnotifikasi.blade.php ENDPATH**/ ?>