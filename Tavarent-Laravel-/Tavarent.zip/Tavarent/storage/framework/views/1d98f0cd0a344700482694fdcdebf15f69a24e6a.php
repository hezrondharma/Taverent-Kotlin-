
<?php $__env->startSection('title','Laporan'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>

    <nav class="main-menu">
        <ul>
            <li class="has-subnav">
                <a href="/admin/listpenginap">
                    <i class="fa fa-list fa-2x"></i>
                    <span class="nav-text">
                        List Penginap
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpemilik">
                    <i class="fa fa-key fa-2x"></i>
                    <span class="nav-text">
                        List Pemilik
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpenginapan">
                    <i class="fa fa-inbox fa-2x"></i>
                    <span class="nav-text">
                        List Penginapan
                    </span>
                </a>

            </li>

            <li>
                <a href="/admin/listnotifikasi">
                    <i class="fa fa-bell fa-2x"></i>
                    <span class="nav-text">
                        List Notifikasi
                    </span>
                </a>
            </li>

            <li>
                <a href="/admin/mail">
                    <i class="fa fa-envelope fa-2x"></i>
                    <span class="nav-text">
                        Send Mail
                    </span>
                </a>
            </li>
        </ul>

        <ul class="logout">
            <li>
                <a href="/admin/logout">
                        <i class="fa fa-power-off fa-2x"></i>
                    <span class="nav-text">
                        Logout
                    </span>
                </a>
            </li>
        </ul>
    </nav>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="area">
    <form action="" method="post"><?php echo csrf_field(); ?>
    <h1>Send Mail</h1>
    <h4>Subject</h4>
    <input type="text" name="subject" id="" class="form-control">
    <?php $__errorArgs = ["subject"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="label-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <h4>User</h4>
    <select name="email" class="form-select">
        <?php if(is_array($user)||is_object($user)): ?>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->email); ?>"><?php echo e($u->username); ?> - <?php echo e($u->nama_lengkap); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <option value=""><?php echo e($user); ?></option>
        <?php endif; ?>
    </select>
    <?php $__errorArgs = ["id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="label-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <h4>Deskripsi</h4>
    <textarea name="deskripsi" id="" cols="30" rows="10" class="form-control"></textarea>
    <input type="submit" value="Send Mail" class="btn btn-success">
    <?php $__errorArgs = ["deskripsi"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="label-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/Admin/mail.blade.php ENDPATH**/ ?>