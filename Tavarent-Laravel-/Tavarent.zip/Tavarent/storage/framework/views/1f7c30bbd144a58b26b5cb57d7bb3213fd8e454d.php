
<?php $__env->startSection('title','Penginap'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/penginap.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("extrajs"); ?>
    <script src="/java/penginap.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpenginap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="justify-content:space-between;margin-top:80px; ">
        <h1>Penginapan Favorit</h1>
        <p class="hint">Ini adalah semua penginapan yang kamu sukai</p>
        <?php $__empty_1 = true; $__currentLoopData = $penginapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="product-card">
            <div class="badge"><?php echo e($p->tipe); ?></div>
            <div class="product-tumb">
                <img src="/storage/imagesPenginapan/<?php echo e($p->id); ?>_1.jpg" alt="" style="height:100%;width:100%;object-fit:cover;">
            </div>
            <div class="product-details">
                <span class="product-catagory"><?php echo e($p->jk_boleh); ?></span>
                <h4><a href="/penyewa/penginapan/<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></a></h4>
                <p>
                    <?php
                        if (strlen($p->deskripsi)>100){
                            echo substr($p->deskripsi,0,80) . " ... ";
                        }else{
                            echo $p->deskripsi;
                        }
                    ?>
                </p>
                <div class="product-bottom-details">
                    <div class="product-price">Rp. <?php echo e($p->harga); ?></div>
                    <div class="product-links">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>Cari penginapan kesukaaanmu dulu</h2>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/penyewa/favorit.blade.php ENDPATH**/ ?>