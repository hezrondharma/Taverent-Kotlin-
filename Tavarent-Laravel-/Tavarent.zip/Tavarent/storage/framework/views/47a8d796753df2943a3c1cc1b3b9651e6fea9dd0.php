
<?php $__env->startSection('title','Pemilik'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/penginap.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpemilik", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:150px; height:1000px;">
<div class="container" style="justify-content:space-between;">
        <?php $__empty_1 = true; $__currentLoopData = $penginapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="product-card">
            <div class="badge"><?php echo e($p->tipe); ?></div>
            <div class="product-tumb">
                <img src="/storage/imagesPenginapan/<?php echo e($p->id); ?>_1.jpg" alt="" style="height:100%;width:100%;object-fit:cover;">
            </div>
            <div class="product-details">
                <span class="product-catagory"><?php echo e($p->jk_boleh); ?></span>
                <h4><a href="/pemilik/penginapan/<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></a></h4>
                <p style="height:100px;">
                    <?php
                        if (strlen($p->deskripsi)>100){
                            echo substr($p->deskripsi,0,100) . " ... ";
                        }else{
                            echo $p->deskripsi;
                        }
                    ?>
                </p>
                <div class="product-bottom-details">
                    <div class="product-price" style="height:40px;">
                    <?php
                        $promo = $p->Promo()->get();
                        if (count($promo)==0){
                            echo 'Rp. '.number_format($p->harga);
                        }else{
                            echo '<p style="text-decoration:line-through;margin-bottom:0px">Rp. '.number_format($p->harga).'</p>';
                        
                            
                            $hargaakhir = 0;
                            foreach($promo as $pro){
                            if ($pro->jenis=="diskon"){
                                $hargaakhir = $p->harga*(100-$pro->jumlah)/100;
                            }else{
                                $hargaakhir = $p->harga-$pro->jumlah;
                            }
                        echo 'Rp. '.number_format($hargaakhir);

                        }
                    
                    }
                    ?>
                    </div>
                    <div class="product-links">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>Tidak ada penginapan</h2>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/pemilik/home.blade.php ENDPATH**/ ?>