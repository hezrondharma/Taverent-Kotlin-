
<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<form action="" method="POST" class="signin-form" >
    <?php echo csrf_field(); ?>
    <input type="hidden" id="hidden" name="hidden" value="login">
    <div class="form-group mb-3">
        <label class="label" for="name">Email</label>
        <input type="text" class="form-control" placeholder="Masukkan Email" value="<?php echo e(old('email')); ?>" name="email">
        <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="email"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
        <label class="label" for="password">Password</label>
        <input id="password" type="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Masukkan Password" name="password">
        <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="password"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
    <div class="form-check">
        <input type="checkbox" class="form-check-input" name="rbremember" value="true">
        <label class="form-check-label" for="remember" >Remember me</label>
    </div>
    <div class="form-group mb-3">
        <button type="submit" class="button form-control rounded px-3" >Login</button>
    </div>
</form>
<p class="text-center">OR<br><a href="<?php echo e(url('/register')); ?>">Go To Register Page</a></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.loginregister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/loginregister/login.blade.php ENDPATH**/ ?>