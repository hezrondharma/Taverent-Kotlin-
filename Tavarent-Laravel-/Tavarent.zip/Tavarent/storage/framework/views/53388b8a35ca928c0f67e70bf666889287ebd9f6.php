
<?php $__env->startSection('title','Pemilik'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/penginap.css')); ?>">
    <link rel="stylesheet" type="text/css"
    href="https://js.api.here.com/v3/3.1/mapsjs-ui.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("extrajs"); ?>
    <script src="<?php echo e(asset('/java/penginap.js')); ?>"></script>
    <script src="<?php echo e(asset('/java/jquery-ui.js')); ?>"></script>
    <script src="https://js.api.here.com/v3/3.1/mapsjs-core.js"
     type="text/javascript" charset="utf-8"></script>
    <script src="https://js.api.here.com/v3/3.1/mapsjs-service.js"
    type="text/javascript" charset="utf-8"></script>
    <script src="https://js.api.here.com/v3/3.1/mapsjs-ui.js"
    type="text/javascript" charset="utf-8"></script>
    <script src="https://js.api.here.com/v3/3.1/mapsjs-mapevents.js"
    type="text/javascript" charset="utf-8"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpemilik", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:150px; height:1000px;">
    <form action="" method="POST" class="signin-form" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <input type="hidden" id="hidden" name="hidden" value="login">
        <div class="form-group mb-3">
            <label class="label" for="name">Upload Foto:</label>
            <input type="file" name="photo[]" id="photo" class="form-control" accept="image/jpeg" multiple >
            <?php $__errorArgs = ["photo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="nproperti"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Nama Properti</label>
            <input type="text" class="form-control" placeholder="Nama Properti" value="<?php echo e(old('nproperti')); ?>" name="nproperti">
            <?php $__errorArgs = ["nproperti"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="nproperti"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Deskripsi Tambahan</label>
            <input type="text" value="<?php echo e(old('deskripsi')); ?>" class="form-control" placeholder="Deskripsi Tambahan" name="deskripsi">
            <?php $__errorArgs = ["deskripsi"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="deskripsi"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Harga Perbulan</label>
            <input type="text" value="<?php echo e(old('harga')); ?>" class="form-control" placeholder="Harga Perbulan" name="harga">
            <?php $__errorArgs = ["harga"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="harga"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Jenis Kelamin yang diperbolehkan</label>
            <select name="selector">
                <option value="campur">Campur</option>
                <option value="pria">Pria</option>
                <option value="wanita">Wanita</option>
            </select>
            <?php $__errorArgs = ["jkelamin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="jkelamin"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Alamat</label>
            <small class="form-text text-muted">Pilih salah satu alamat dari autosuggest!</small>
            <input type="hidden" value="<?php echo e(old('koordinat')); ?>" name="koordinat" id="koordinat">
            <input type="text" value="<?php echo e(old('alamat')); ?>" class="form-control" id="alamat" placeholder="Masukkan Alamat" name="alamat">
            <?php $__errorArgs = ["alamat"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="alamat"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ["koordinat"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="alamat"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div style="height:300px;border-radius:10px;border:1px solid gray; overflow:hidden" id="mapContainer"></div>

        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Fasilitas Minimal 3</label>
            <div>
                <input type="checkbox" name="ac" value="yes">
                <label >Air Conditioner</label>
                <input type="checkbox" name="termasuklistrik" value="yes">
                <label >Termasuk Listrik</label>
                <input type="checkbox" name="kdalam" value="yes">
                <label >K. Mandi Dalam</label>
                <br>
                <input type="checkbox" name="kursi" value="yes">
                <label >Kursi</label>
                <input type="checkbox" name="meja" value="yes">
                <label >Meja</label>
                <input type="checkbox" name="wifi" value="yes">
                <label >Wifi</label>
                <br>
                <input type="checkbox" name="kasurdouble"  value="yes">
                <label >Kasur Double</label>
                <input type="checkbox" name="tv" value="yes">
                <label >Tv</label>
                <input type="checkbox" name="kasursingle" value="yes">
                <label >Kasur Single</label>
                <br>
                <input type="checkbox" name="jendela"  value="yes">
                <label >Jendela</label>
                <input type="checkbox" name="airpanas" value="yes">
                <label >Air Panas</label>
                <input type="checkbox" name="dapur" value="yes">
                <label >Dapur</label>

        </div> <br>
        <label class="label" for="name">Jenis Penginapan</label>
        <div class="form-group mb-4">
            <label class="label" for="name">Apartemen</label> <input type="radio" name="rbJenis" value="Apartemen"><i class="validation"></i>
            <label class="label" for="name">Kos</label>  <input type="radio" name="rbJenis" value="Kos"><i class="validation"></i><br>
            <?php $__errorArgs = ["rbJenis"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="rbJenis"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
            <button type="submit" class="button form-control rounded px-3" >Daftar</button>
        </div>
    </form>
</div>
<script>
    $(document).ready(function(){ 
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(getLocation);
        } else { 
            alert("Nyalakan Lokasi");
        }    
        
        var platform;
        var map;
        var marker;

        function getLocation(position){
            platform = new H.service.Platform({
                'apikey': 'rQWmEReEoxYDzqrD4qDxp08gW5ZGMBv_0zXDW547jRg'
            });

            var defaultLayers = platform.createDefaultLayers();
            map = new H.Map(
                document.getElementById('mapContainer'),
                defaultLayers.vector.normal.map,
                {
                    zoom: 14,
                    center: { lat: position.coords.latitude, lng: position.coords.longitude }
                }
            );
            var mapevents = new H.mapevents.MapEvents(map)
            var ui = H.ui.UI.createDefault(map, defaultLayers);
            ui.getControl('mapsettings').setDisabled(true)
            map.addEventListener('tap', function(evt) {
                // Log 'tap' and 'mouse' events:
                console.log(evt.type, evt.currentPointer.type); 
            });
            var behavior = new H.mapevents.Behavior(mapevents);

            
            marker = new H.map.Marker({ lat: position.coords.latitude, lng: position.coords.longitude });
            // Add the marker to the map and center the map at the location of the marker:
            map.addObject(marker);
            map.setCenter({ lat: position.coords.latitude, lng: position.coords.longitude });
        }

        var typingTimer;                //timer identifier
        var doneTypingInterval = 2000;  //time in ms, 5 seconds for example

        $("#alamat").on("keydown",function(){
            clearTimeout(typingTimer)
        });
        $("#alamat").on('keyup', function () {
            clearTimeout(typingTimer);
            typingTimer = setTimeout(doneTyping, doneTypingInterval);
        });

        function doneTyping () {
            console.log("eiwjfoe");
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(getAddress);
            }
        }

        function getAddress(position){
            var autocomplete = [];
            var location = [];

            var platform = new H.service.Platform({
                'apikey': 'rQWmEReEoxYDzqrD4qDxp08gW5ZGMBv_0zXDW547jRg'
            });
            var service = platform.getSearchService();

            service.autosuggest({
            // Search query
                q: String($('#alamat').val()),
                at: position.coords.latitude+','+position.coords.longitude,
            }, (result) => {

                var idx = 1;
                result.items.forEach((item)=>{
                    autocomplete.push({label:item.title,idx:idx});
                    location.push({koordinat:item.position,idx:idx})
                    idx++;
                });
            });
            console.log(autocomplete.toString());
            $("#alamat").autocomplete({
                source: autocomplete,
                minLenght: 0,
                autoFocus: true,
                select: function(event,ui){
                    console.log($("#koordinat").val());
                    $("#koordinat").val(location[ui.item.idx].koordinat.lat+","+location[ui.item.idx].koordinat.lng);
                    console.log($("#koordinat").val());
                
                }
            }).focus(function () {
                $(this).autocomplete("search");
            });
            $("#alamat").attr("autocomplete", "on");

        }
        
        
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/Pemilik/kelola.blade.php ENDPATH**/ ?>