
<?php $__env->startSection('title','Register'); ?>

<?php $__env->startSection('content'); ?>
<form action="" method="POST" class="signin-form">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="hidden" name="hidden" value="register">
    <div class="form-group mb-3">
        <label class="label" for="name">Email</label>
        <input type="text" class="form-control" placeholder="Masukkan Email" name="email" value="<?php echo e(old('email')); ?>">
        <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="email"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
        <label class="label" for="name">Username</label>
        <input type="text" class="form-control" placeholder="Masukkan Username" name="username" value="<?php echo e(old('username')); ?>">
        <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="Username"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
        <label class="label" for="name">Nama</label>
        <input type="text" class="form-control" placeholder="Masukkan Nama" name="nama" value="<?php echo e(old('nama')); ?>">
        <?php $__errorArgs = ["nama"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="nama"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
        <label class="label" for="name">Nomor Telepon</label>
        <input type="text" class="form-control" placeholder="Nomor Telepon" name="notelp" value="<?php echo e(old('notelp')); ?>">
        <?php $__errorArgs = ["notelp"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="notelp"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group mb-4">
        <label class="label" for="password">Password</label>
        <input id="password" type="password" class="form-control" placeholder="Masukkan Password" name="password"  value="<?php echo e(old('password')); ?>">
        <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="password"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-4">
        <label class="label" for="name">Pemilik</label> <input type="radio" name="rbJenis" value="pemilik"><i class="validation"></i>
        <label class="label" for="name">Penginap</label>  <input type="radio" name="rbJenis" value="penginap"><i class="validation"></i><br>
        <?php $__errorArgs = ["rbJenis"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label class="label text-danger" for="rbJenis"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-3">
        <button type="submit" class="button form-control rounded px-3">Register</button>
    </div>
</form>
<p class="text-center">OR<br><a href="<?php echo e(url('/login')); ?>">Go To Login Page</a></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.loginregister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/loginregister/register.blade.php ENDPATH**/ ?>