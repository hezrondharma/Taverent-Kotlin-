
<?php $__env->startSection('title','Pemilik'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/penginap.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("extrajs"); ?>
    <script src="/java/penginap.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpemilik", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="overflow:hidden;height:auto;padding-bottom:100px;padding-top:100px;">
        <div class="left" style="float:left;width:30%;height:100%">
        <h1>Tambah Promo</h1>
        <form action="" method="post"><?php echo csrf_field(); ?>
            <p class="hint">Judul Promo</p>
            <input type="text" name="nama" class="form-control">
            <p class="hint">Jenis Promo</p>
            <select name="jenis" id="jenis" class="form-select">
                <option value="diskon">Diskon</option>
                <option value="nominal">Nominal</option>
                
            </select>
            <p class="hint">Jumlah Promo</p>
            <input type="text" name="jumlah" class="form-control" id="jumlah">
            <p class="hint">Tanggal Mulai</p>
            <input type="date" name="tanggal_mulai" class="form-control">
            <p class="hint">Tanggal Selesai</p>
            <input type="date" name="tanggal_selesai" class="form-control">
            <p class="hint">Pilih Penginapan</p>
            <select name="id_penginapan" class="form-select" id="harga">
                <?php $__currentLoopData = $penginapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" value2="<?php echo e($p->harga); ?>"><?php echo e($p->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <p style="font-size:15pt;font-weight:bold;text-decoration:line-through;" id="hargaawal">Rp -</p>
            <p style="font-size:15pt;font-weight:bold;" id="hargaakhir">Rp -</p>
            <br>
            <input type="submit" value="Tambah Promo" class="btn btn-success">
        </div>
        </form>
        <div class="right" style="float:left;width:65%;margin-left:5%;height:100%">
            <table class="table">
                <thead>
                    <tr>
                        <td>No</td>
                        <td>Nama Penginapan</td>
                        <td>Harga Awal</td>
                        <td>Harga Akhir</td>
                        <td>Mulai</td>
                        <td>Akhir</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($idx+1); ?></td>
                            
                            <td><?php echo e($p->Penginapan->nama); ?></td>
                            <td><?php echo e(number_format($p->Penginapan->harga)); ?></td>
                            <td>
                            <?php
                            if ($p->jenis=="diskon"){
                                $hargaakhir = $p->Penginapan->harga*(100-$p->jumlah)/100;
                            }else{
                                $hargaakhir = $p->Penginapan->harga-$p->jumlah;
                            }
                            echo 'Rp. '.number_format($hargaakhir);
                            ?>
                            </td>
                            <td><?php echo e(substr($p->tanggal_mulai,0,10)); ?></td>
                            <td><?php echo e(substr($p->tanggal_selesai,0,10)); ?></td>
                            <td><form action="/pemilik/promo/<?php echo e($p->id); ?>" method="post"><?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-danger">
                            </form></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h1>Masih Belum ada Promo</h1>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#jumlah").on("input",function(){
                var jumlah = $(this).val();
                var tipe = $("#jenis").val();
                var harga = $("#harga option:selected").attr("value2");
                console.log(jumlah+tipe+harga);
                if ( jumlah!=""&&jumlah>0){
                    var hargaakhir= 0;
                    const formatter = new Intl.NumberFormat('id-ID', {
                    style: 'currency',
                    currency: 'IDR',});
                    if (tipe=="diskon"){
                        hargaakhir = harga*(100-jumlah)/100;
                    }else{
                        hargaakhir = harga-jumlah;
                    }
                    console.log(hargaakhir);
                    $("#hargaakhir").html(formatter.format(hargaakhir));
                }else{
                    $("#hargaakhir").html("Rp -")
                }
            });
            $("#jenis").change(calculateprice());
            $("#harga").change(calculateprice());
            function calculateprice(){
                var jumlah = $("#harga").val();
                var tipe = $("#jenis").val();
                var harga = $("#harga option:selected").attr("value2");
                const formatter = new Intl.NumberFormat('id-ID', {
                    style: 'currency',
                    currency: 'IDR',});

                $("#hargaawal").html(formatter.format(harga));
                console.log(jumlah+tipe+harga);
                if ( jumlah!=""&&harga>0&&harga.isNumeric){
                    var hargaakhir= 0;
                    
                    if (tipe=="diskon"){
                        hargaakhir = harga*(100-jumlah)/100;
                    }else{
                        hargaakhir = harga-jumlah;
                    }
                    $("#hargaakhir").html(formatter.format(hargaakhir));
                }else{
                    $("#hargaakhir").html("Rp -")
                }
            }
        });
        
    </script>
    <!-- <?php 
        echo $java;
    ?> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/pemilik/promo.blade.php ENDPATH**/ ?>