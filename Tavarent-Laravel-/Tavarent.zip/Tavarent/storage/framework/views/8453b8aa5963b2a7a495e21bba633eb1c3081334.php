
<?php $__env->startSection('title','Ubah Pemilik'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
<a href="/admin/listpemilik" style="text-decoration: none">
    <i class="fa fa-arrow-circle-o-left" style="color: black;"></i>
</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Ubah Pemilik</h1>
    <form action="<?php echo e(url("admin/listpemilik/ubah/$pemilik->id")); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="id" value="<?php echo e($pemilik->id); ?>">
        <div class="form-group mb-3">
            <label class="label" for="name">Email</label>
            <input type="text" class="form-control" placeholder="Masukkan Email" name="email" value="<?php echo e(old('email',$pemilik->email)); ?>">
            <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="email"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Username</label>
            <input type="text" class="form-control" placeholder="Masukkan Username" name="username" value="<?php echo e(old('username',$pemilik->username)); ?>">
            <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="Username"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Nama</label>
            <input type="text" class="form-control" placeholder="Masukkan Nama" name="nama" value="<?php echo e(old('nama',$pemilik->nama_lengkap)); ?>">
            <?php $__errorArgs = ["nama"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="nama"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label class="label" for="name">Nomor Telepon</label>
            <input type="text" class="form-control" placeholder="Nomor Telepon" name="notelp" value="<?php echo e(old('notelp',$pemilik->no_telp)); ?>">
            <?php $__errorArgs = ["notelp"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="notelp"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-4">
            <label class="label" for="password">Password</label>
            <input id="password" type="password" class="form-control" placeholder="Masukkan Password" name="password"  value="<?php echo e(old('password',$pemilik->password)); ?>">
            <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="password"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-4">
            <label class="label" for="password">Saldo</label>
            <input id="" type="number" class="form-control" placeholder="Masukkan Saldo" name="saldo"  value="<?php echo e(old('saldo',$pemilik->saldo)); ?>">
            <?php $__errorArgs = ["saldo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="label text-danger" for="saldo"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <input type="submit" value="ubah" class="btn btn-success">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/Admin/ubahlistpemilik.blade.php ENDPATH**/ ?>