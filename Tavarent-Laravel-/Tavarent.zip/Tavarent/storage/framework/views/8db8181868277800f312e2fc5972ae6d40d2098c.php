<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <script src="/java/jquery.min.js"></script>
    
    <?php echo $__env->yieldContent("extracss"); ?>
    <?php echo $__env->yieldContent("extrajs"); ?>
</head>
<body class="hero-anime">
    <?php echo $__env->yieldContent("navbar"); ?>
    <?php echo $__env->yieldContent("content"); ?>
    
</body>
</html>
<?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/layout/layout.blade.php ENDPATH**/ ?>