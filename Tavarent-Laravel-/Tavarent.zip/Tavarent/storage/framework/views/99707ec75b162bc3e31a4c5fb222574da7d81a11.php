<footer class="text-center text-white" style="background-color: #0a4275;">

    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        <h3>Taravent</h3> <br>
       <h6 class="p-3"><a href="">About Us</a> | <a href="<?php echo e(url('/terms')); ?>">Terms & Conditions </a> | <a href="">Help Center</a></h4>  <br>
      © 2022 Copyright: Taravent
    </div>

  </footer>


<?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/footer.blade.php ENDPATH**/ ?>