
<?php $__env->startSection('title','List Penginap'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
<div class="area"></div>
    <nav class="main-menu">
        <ul>
            <li class="has-subnav">
                <a href="/admin/listpenginap">
                    <i class="fa fa-list fa-2x"></i>
                    <span class="nav-text">
                        List Penginap
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpemilik">
                    <i class="fa fa-key fa-2x"></i>
                    <span class="nav-text">
                        List Pemilik
                    </span>
                </a>

            </li>
            <li class="has-subnav">
                <a href="/admin/listpenginapan">
                    <i class="fa fa-inbox fa-2x"></i>
                    <span class="nav-text">
                        List Penginapan
                    </span>
                </a>

            </li>

            <li>
                <a href="/admin/listnotifikasi">
                    <i class="fa fa-bell fa-2x"></i>
                    <span class="nav-text">
                        List Notifikasi
                    </span>
                </a>
            </li>

            <li>
                <a href="/admin/mail">
                    <i class="fa fa-envelope fa-2x"></i>
                    <span class="nav-text">
                        Send Mail
                    </span>
                </a>
            </li>
        </ul>

        <ul class="logout">
            <li>
                <a href="/admin/logout">
                        <i class="fa fa-power-off fa-2x"></i>
                    <span class="nav-text">
                        Logout
                    </span>
                </a>
            </li>
        </ul>
    </nav>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="area">
    <br>
    <h1>List Penginap</h1>
<?php if(Session::has("pesanSukses")): ?>
<div class="alert alert-success"><?php echo e(Session::get("pesanSukses")); ?></div>
<?php endif; ?>

<?php if(Session::has("pesanGagal")): ?>
<div class="alert alert-danger"><?php echo e(Session::get("pesanGagal")); ?></div>
<?php endif; ?>

<?php if(!$penginap->isEmpty()): ?>
    <table class="table table table-striped table-hover table-bordered border-dark">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
                <th>Nama Lengkap</th>
                <th>Email</th>
                <th>No Telephone</th>
                <th>Saldo</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $penginap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penginaps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($penginaps->id); ?></td>
                <td><?php echo e($penginaps->username); ?></td>
                <td><?php echo e($penginaps->password); ?></td>
                <td><?php echo e($penginaps->nama_lengkap); ?></td>
                <td><?php echo e($penginaps->email); ?></td>
                <td><?php echo e($penginaps->no_telp); ?></td>
                <td><?php echo e($penginaps->saldo); ?></td>
                <td>
                    <a href="<?php echo e(url("admin/listpenginap/ubah/$penginaps->id")); ?>" class="btn btn-primary">Ubah</a>
                    <?php if($penginaps->trashed()): ?>
                    <a href="<?php echo e(url("admin/listpenginap/hapus/$penginaps->id")); ?>" class="btn btn-success">Unban</a>
                    <?php else: ?>
                    <a href="<?php echo e(url("admin/listpenginap/hapus/$penginaps->id")); ?>" class="btn btn-danger">Ban</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>


    </table>
<?php else: ?>
<h1>tidak ada daftar penginap</h1>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/Admin/listpenginap.blade.php ENDPATH**/ ?>