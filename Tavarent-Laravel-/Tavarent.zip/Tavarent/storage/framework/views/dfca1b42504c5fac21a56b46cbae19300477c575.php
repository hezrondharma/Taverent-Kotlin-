
<?php $__env->startSection('title','Penginap'); ?>
<?php $__env->startSection("extracss"); ?>
    <link rel="stylesheet" href="/css/penginap.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("extrajs"); ?>
    <script src="/java/penginap.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make("navbar.navbarpenginap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="padding-top:100px;">
        <?php $__empty_1 = true; $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="/penyewa/penginapan/<?php echo e($p->id); ?>" style="color:black;text-decoration:none;">
        <div class="kotak" style="border: 1px solid gray;border-radius:20px;padding-left:10%;padding-right:10%;margin-bottom:20px;padding-top:20px;padding-bottom:20px;overflow:hidden;">
        <div class="left" style="float:left;">
            <div style="font-size:20pt;font-weight:bold;color:#fbb72c;">ORDER<?php echo e($p->id); ?></div>
            <div style="font-weight:bold;">Total: Rp. <?php echo e(number_format($p->total,2)); ?></div>
            <table>
                <tr style="font-weight:bold;font-size:10pt;">
                    <td style="margin-right:20px;">Tanggal Mulai</td>
                    <td>Tanggal Selesai</td>
                </tr>
                <tr>
                    <td style="padding-right:20px;"><?php echo e(date("F j, Y",strtotime($p->tanggal_mulai))); ?></td>
                    <td><?php echo e(date("F j, Y",strtotime($p->tanggal_mulai))); ?></td>
                </tr>
            </table>
            <div class="hint">Nama Penginapan: <?php echo e($p->Penginapan->nama); ?></div>
            
        </div>
        <div class="right" style="float:right;width:10%;height:10%;margin-top:30px;">
            <img src="<?php echo e(asset('img/paid.png')); ?>" alt="" style="object-fit: contain;width:100px;">
    </div>
        </div>
        
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>Kamu belum pernah sewa penginapan</h1>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Johans\Kuliah\Semester 5\TAVARENT\Taverent-Kotlin-\Tavarent-Laravel-\Tavarent\resources\views/penyewa/kossaya.blade.php ENDPATH**/ ?>